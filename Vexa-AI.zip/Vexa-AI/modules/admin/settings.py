STATE_ADD_UID = "admin:add:uid"
STATE_ADD_AMT = "admin:add:amt"
STATE_SUB_UID = "admin:sub:uid"
STATE_SUB_AMT = "admin:sub:amt"
STATE_MSG_UID = "admin:msg:uid"
STATE_MSG_TXT = "admin:msg:txt"
STATE_CAST_TXT = "admin:cast:txt"

STATE_SET_BONUS = "admin:set:bonus"
STATE_SET_FREE  = "admin:set:free"
STATE_SET_TG    = "admin:set:tg"
STATE_SET_IG    = "admin:set:ig"

STATE_USER_LOOKUP = "admin:user:lookup"